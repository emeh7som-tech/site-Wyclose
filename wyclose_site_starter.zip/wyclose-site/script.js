(function(){
  const $ = (s, r=document)=>r.querySelector(s);
  $("#year").textContent = new Date().getFullYear();
  if("serviceWorker" in navigator){
    window.addEventListener("load", ()=>{
      navigator.serviceWorker.register("sw.js").catch(console.error);
    });
  }
  let deferredPrompt;
  window.addEventListener("beforeinstallprompt", (e)=>{
    e.preventDefault(); deferredPrompt = e;
    const hint = document.getElementById("pwaHint");
    if(hint) hint.hidden = false;
  });
  const form = document.getElementById("contactForm");
  if(form){
    form.addEventListener("submit",(e)=>{
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      const inbox = JSON.parse(localStorage.getItem("wyclose_inbox")||"[]");
      inbox.push({...data, ts: Date.now()});
      localStorage.setItem("wyclose_inbox", JSON.stringify(inbox));
      document.getElementById("formStatus").textContent = "Mensagem registrada!";
      form.reset();
    });
  }
  const openAssistant = document.getElementById("openAssistant");
  const modal = document.getElementById("assistantModal");
  const closeAssistant = document.getElementById("closeAssistant");
  const body = document.getElementById("assistantBody");
  const assistantForm = document.getElementById("assistantForm");
  const assistantInput = document.getElementById("assistantInput");
  if(openAssistant && modal){ openAssistant.addEventListener("click", ()=> modal.hidden = false); }
  if(closeAssistant){ closeAssistant.addEventListener("click", ()=> modal.hidden = true); }
  if(assistantForm){
    assistantForm.addEventListener("submit",(e)=>{
      e.preventDefault();
      const text = assistantInput.value.trim();
      if(!text) return;
      append("user", text);
      assistantInput.value = "";
      setTimeout(()=> append("bot", "Você disse: “"+text+"”. No futuro, aqui entra a IA do Wyclose."), 300);
    });
  }
  function append(role,text){
    const el = document.createElement("div");
    el.className = "msg "+(role==="bot"?"bot":"");
    el.textContent = text;
    body.appendChild(el);
    body.scrollTop = body.scrollHeight;
  }
})();