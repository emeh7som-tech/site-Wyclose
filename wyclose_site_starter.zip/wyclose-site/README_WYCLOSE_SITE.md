# Wyclose — Site Starter (PWA)
Base do site Wyclose, pronta para publicar.

## Estrutura
- index.html
- style.css
- script.js
- manifest.json
- sw.js
- assets/icon-192.png, assets/icon-512.png

## Deploy rápido (Vercel)
Crie um novo projeto estático e aponte para a pasta `wyclose-site/`.

## Local
`python -m http.server 5173` e acesse `http://localhost:5173/wyclose-site/`.

## Próximos passos
- Conectar formulário a um painel/SMTP.
- Integrar IA real no módulo do assistente.
